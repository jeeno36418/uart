
/* 
 * File:   GLOBAL.h
 * Author: Kanna
 *
 * Created on February 13, 2018, 2:42 AM
 */

#ifndef GLOBAL_H
#define	GLOBAL_H
#include<pic16f877a.h>
#ifdef	__cplusplus
extern "C" {
#endif

void adc_init(void);
void delay(char count);
void adc_channel(unsigned char);
unsigned char adc_res(void);
unsigned int adc_res_10_bit(void);
void uart_putc(unsigned char data);
void i2c_lcd_data_write(unsigned char data_byte);
void i2c_lcd_ctrl_write(unsigned char ctrl_byte);
void lcd_puts(const char *);
void lcd_put_array(char *);
void lcd_putn(unsigned int);
void lcd_putnd(unsigned int,char);
void lcd_putc(unsigned char);
void lcd_puta(unsigned char);
void lcd_goto(unsigned char);
void lcd_goto_pos(unsigned char);
void lcd_clrscr();
void lcd_init(void);
void lcd_cmd_write(unsigned char);
void lcd_data_write(unsigned char);
void uart_puts(const char *);
void uart_put_array(char *);
void uart_putn(unsigned int);
void uart_putnd(unsigned int,char);

void uart_init(unsigned int baud, unsigned char fosc);
unsigned char uart_getc(void);
void next_line(void);
void next_pos(void);
void tab(unsigned char);
void goto_start(void);



#ifdef	__cplusplus
}
#endif

#endif	/* GLOBAL_H */

