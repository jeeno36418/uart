#include <stdio.h>
void DelayUs(unsigned char x);
void DelayMs(unsigned char cnt);

void DelayUs(char x) {
			unsigned char _dcnt;
			_dcnt = x;
			while(--_dcnt != 0) {

			}
		}
void DelayMs(unsigned char cnt)
{

	unsigned char	i;
	do {
		i = 4;
		do {
			DelayUs(250);
		} while(--i);
	} while(--cnt);

}