/*--------------------------------------------------------------*/
/*			  Selects Analog channels AN0 to AN4				*/
/*--------------------------------------------------------------*/
/*  	 ADC acq. freq (app)  -  10000 samples/sec (9900 typ)	*/
/*--------------------------------------------------------------*/
#ifndef _ADC_DRIVER_C_
#define _ADC_DRIVER_C_
#include <pic16f877a.h>
int adch,adcl;
#define  ADGO GO
/*--------------------------------------------------------------*/


/*--------------------------------------------------------------*/

//void main(){}

/*--------------------------------------------------------------*/
void delay(char count)
{
    int i;

    for(i=0 ; i<count;i++);
}
void adc_init()
{
	delay(100);
	ADCON1 = 0x82;			// Configures the functions of the port pins (only PORTA pins are used)
}

/*--------------------------------------------------------------*/

void adc_channel(unsigned char ch)
{
	delay(100);
	ADCON0 = 193 | (ch << 3); 		// Turns ON the A/D module (selects channels AN0 to AN4 )	
}

/*--------------------------------------------------------------*/

unsigned char adc_res()
{
	ADRESL = 0;				// Clears the contents of the AD result register 
	delay(20);			// Acquisition delay for charging the sampling capacitor
	ADGO = 1;				// Starts the A/D Conversion 
	
	while(ADGO)				// Waits until the ADGO bit becomes 0 (conversion to complete)
		continue;

	return ADRESL;	 
}

/*--------------------------------------------------------------*/
unsigned int adc_res_10_bit()
{
//	unsigned int left_res, right_res, result;
		

	ADRESL = 0;				// Clears the contents of the AD result register 
	ADRESH = 0;
	delay(20);			// Acquisition delay for charging the sampling capacitor
	ADGO = 1;				// Starts the A/D Conversion 
	
	while(ADGO)				// Waits until the ADGO bit becomes 0 (conversion to complete)
		continue;

	adch=ADRESH;
        adcl=ADRESL;
	return (((unsigned int)ADRESH)<<8)|(ADRESL);

}
/*-------------------------------------*/
#endif




