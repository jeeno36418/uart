#include <pic16f877a.h>
#include<Stdio.h>
#include<string.h>

//#include"adc_driver.c"
#include "GLOBAL.h"

//#include "i2c_lcd_driver_new.c"
//#include "uart_driver.c"
//#include "hyper_terminal.c"e

extern int adch,adcl;
extern void setup_i2c_port();
extern void setup_i2c_master();
char display_buffer[50];
unsigned int timer=1,unit=0;
float  voltage[3]={0}, current[3]={0},cost[3]={0},power[3]={0};
/*--------------------------------------------*/

#pragma config CONFIG=0x00;

/*--------------------------------------------*/
//.extern void DelayMs(unsigned char cnt);
void main()
{
        unsigned int adc1,adc2,i,sample[3];
        
        
	TRISB = 0x00;
	PORTB = 0x00;

	
	setup_i2c_port();
	setup_i2c_master();
	adc_init();
	uart_init(9600,16);				// Initialize UART to 9600 baud-rate
	delay(100);
//	lcd_init();
//	lcd_goto(1);
//	lcd_puts("Current:");
//	lcd_goto(21);
//	lcd_puts("Voltage:");
        
	
	

	while(1)
	{
			
                uart_puts("**********************************************************");
                next_line();

                next_line();
               
                  
            for(i=0;i<3;i++)
            {
                  adc_channel(i);
                  sample[i] = adc_res_10_bit();// 10 bit adc
                  voltage[i]=(sample[i]*4.8828);// sample * 5 volts / 1023 resolution of adc
                  current[i] = ((voltage[i]-2500)/185)*1000;// ACS712 Current sensor data sheet current calculation 2500 is offset voltage 185 is 5A sentivity, 1000 is to measure current in milliamphere
                  power[i] = (30*current[i])/1000;// source voltae is 30v
            }
                 if (timer %10==0)
                 {
                     unit++;
              
                 }

            for(i = 0; i<3 ; i++)
            {
                  cost[i]= power[i]/1000 * unit*10;// cost = enery * no of hours // enery is measured in kilo watts so converting power to kilo watts
                  sprintf(display_buffer,"Power%d:%5.5f kW",i+1,power[i]/1000);
                  uart_puts(display_buffer);
                  next_line();
                  sprintf(display_buffer,"Current_Load_%d: %4.0f mA",i+1,current[i]);
                  uart_puts(display_buffer);
                  next_line();
                  sprintf(display_buffer,"Unit:%d",unit);
                  uart_puts(display_buffer);
                  next_line();
                  sprintf(display_buffer,"Cost for Load%d Rs:%5.2f",i+1,cost[i]);
                  uart_puts(display_buffer);
                  next_line();
                  next_line();
                  
            }
            sprintf(display_buffer,"Total cost Rs:%5.2f",(cost[0]+cost[1]+cost[2]));
            uart_puts(display_buffer);
            next_line();
            timer++;
                
             // DelayMs(500);
          }

       
}




//power