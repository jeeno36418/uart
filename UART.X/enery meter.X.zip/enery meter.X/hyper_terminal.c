#include<pic.h>
//#include "delay.c"
//#include "uart_driver.c"
extern void uart_putc(unsigned char data);
/*------------------------------------*/



/*------------------------------------*/

 //void main(){}

/*------------------------------------*/

void next_line(){
	uart_putc(0x0a);			// Line feed
	uart_putc(0x0d);			// Carriage return
}	

/*------------------------------------*/

void goto_start(){
	uart_putc(0x0d);			// Carriage return
}

/*------------------------------------*/

void next_pos(){
	char i;
	for(i=1; i<=2; i++)
		uart_putc(0x09);
}
/*------------------------------------*/
void tab(unsigned char i){
	while(i){
		uart_putc(0x09);								// Horizontal Tab
		i--;
	}
}
/*----------------------------------------------------*/
